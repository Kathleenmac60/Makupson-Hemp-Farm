
import React from "react";

export default function MakupsonFarmWebsite() {
  return (
    <div style={{ fontFamily: "sans-serif", padding: "40px" }}>
      <h1>Makupson Farming LLC</h1>
      <p>Premium indoor-grown hemp • Disabled veteran-owned</p>
      <p>Website build verified and running.</p>
    </div>
  );
}
